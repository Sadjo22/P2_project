#ifndef ITEMS_WINDOW_H
#define ITEMS_WINDOW_H

#include<QListView>

class Items_Window:public QListView{

public:
    Items_Window(QWidget* =nullptr);


};

#endif // ITEMS_WINDOW_H
